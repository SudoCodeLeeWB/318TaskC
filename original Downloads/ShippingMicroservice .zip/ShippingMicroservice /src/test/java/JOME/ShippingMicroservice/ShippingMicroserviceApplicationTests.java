package JOME.ShippingMicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShippingMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
